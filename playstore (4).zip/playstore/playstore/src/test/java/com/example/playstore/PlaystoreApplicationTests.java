package com.example.playstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaystoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
