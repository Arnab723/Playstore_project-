package com.example.playstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.playstore.entity.Application;

public interface ApplicationRepository extends JpaRepository<Application, Long> {
 Application findByName(String name);
}
