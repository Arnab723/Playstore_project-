package com.example.playstore.controller;

import com.example.playstore.entity.Review;
import com.example.playstore.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    // Add a new review
    @PostMapping("/add")
    public ResponseEntity<Review> addReview(
            @RequestParam Long applicationId,
            @RequestParam Long userId,
            @RequestBody Review reviewRequest) {
        try {
            Review review = reviewService.addReview(
                    applicationId,
                    userId,
                    reviewRequest.getContent(),
                    reviewRequest.getRating()
            );
            return new ResponseEntity<>(review, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    // Get all reviews for an application
    @GetMapping("/application/{applicationId}")
    public ResponseEntity<List<Review>> getReviewsByApplication(@PathVariable Long applicationId) {
        List<Review> reviews = reviewService.getReviewsByApplicationId(applicationId);
        return new ResponseEntity<>(reviews, HttpStatus.OK);
    }

    // Get all reviews by a user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Review>> getReviewsByUser(@PathVariable Long userId) {
        List<Review> reviews = reviewService.getReviewsByUserId(userId);
        return new ResponseEntity<>(reviews, HttpStatus.OK);
    }

    // Delete a review
    @DeleteMapping("/delete/{reviewId}")
    public ResponseEntity<Void> deleteReview(
            @PathVariable Long reviewId,
            @RequestParam Long userId) {
        try {
            reviewService.deleteReview(reviewId, userId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
