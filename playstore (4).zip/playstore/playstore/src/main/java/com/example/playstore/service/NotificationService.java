package com.example.playstore.service;

//src/main/java/com/example/playstore/service/NotificationService.java



import com.example.playstore.entity.Notification;
import com.example.playstore.entity.User;
import com.example.playstore.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

@Service
public class NotificationService {

 @Autowired
 private NotificationRepository notificationRepository;

 // Send a notification to a user
 public Notification sendNotification(String message, Optional<User> user) {
     Notification notification = new Notification();
     notification.setMessage(message);
     notification.setTimestamp(new Date());
     notification.setUser(user);

     return notificationRepository.save(notification);
 }
}

