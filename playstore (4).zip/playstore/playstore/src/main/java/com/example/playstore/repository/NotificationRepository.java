package com.example.playstore.repository;

//src/main/java/com/example/playstore/repository/NotificationRepository.java



import com.example.playstore.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
 // Custom queries can be added here if needed
}
