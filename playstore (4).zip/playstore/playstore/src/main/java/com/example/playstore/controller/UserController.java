package com.example.playstore.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.playstore.entity.User;
import com.example.playstore.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {

 @Autowired
 private UserService userService;

 // Register a new user
 @PostMapping("/register")
 public ResponseEntity<User> registerUser(@RequestBody User user) {
     User registeredUser = userService.registerUser(user);
     return new ResponseEntity<>(registeredUser, HttpStatus.CREATED);
 }

 // Login user (for simplicity, this example doesn't include JWT handling)
 @PostMapping("/login")
 public ResponseEntity<String> loginUser(@RequestBody User user) {
     User existingUser = userService.findByUsername(user.getUsername());
     if (existingUser != null && existingUser.getPassword().equals(user.getPassword())) {
         // In a real application, you would return a JWT token here
         return new ResponseEntity<>("Login successful", HttpStatus.OK);
     } else {
         return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
     }
 }

 // Fetch user details by username
 @GetMapping("/{username}")
 public ResponseEntity<User> getUserByUsername(@PathVariable String username) {
     User user = userService.findByUsername(username);
     if (user != null) {
         return new ResponseEntity<>(user, HttpStatus.OK);
     } else {
         return new ResponseEntity<>(HttpStatus.NOT_FOUND);
     }
 }

 // Additional endpoints can be added here as needed
}

