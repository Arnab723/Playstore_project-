package com.example.playstore.entity;

//src/main/java/com/example/playstore/entity/Notification.java


import jakarta.persistence.*;
import java.util.Date;
import java.util.Optional;

@Entity
@Table(name = "notifications")
public class Notification {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @Column(nullable = false)
 private String message;

 @Column(nullable = false)
 private Date timestamp;

 @ManyToOne
 @JoinColumn(name = "user_id", nullable = false)
 private Optional<User> user;

 // Getters and Setters
 public Long getId() {
     return id;
 }

 public void setId(Long id) {
     this.id = id;
 }

 public String getMessage() {
     return message;
 }

 public void setMessage(String message) {
     this.message = message;
 }

 public Date getTimestamp() {
     return timestamp;
 }

 public void setTimestamp(Date timestamp) {
     this.timestamp = timestamp;
 }

 public Optional<User> getUser() {
     return user;
 }

 public void setUser(Optional<User> user2) {
     this.user = user2;
 }

public void setMessage1(String message2) {
	// TODO Auto-generated method stub
	
}
}

