package com.example.playstore.repository;

import com.example.playstore.entity.Review;
import com.example.playstore.entity.Application;
import com.example.playstore.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByApplication(Application application);

    List<Review> findByUser(User user);

    List<Review> findByApplicationId(Long applicationId);

    List<Review> findByUserId(Long userId);
}