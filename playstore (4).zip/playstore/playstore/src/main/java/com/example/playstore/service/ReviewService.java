package com.example.playstore.service;

import com.example.playstore.entity.Review;
import com.example.playstore.entity.Application;
import com.example.playstore.entity.User;
import com.example.playstore.repository.ReviewRepository;
import com.example.playstore.repository.ApplicationRepository;
import com.example.playstore.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private UserRepository userRepository;

    public Review addReview(Long applicationId, Long userId, String content, int rating) throws Exception {
        Optional<Application> applicationOpt = applicationRepository.findById(applicationId);
        Optional<User> userOpt = null;//userRepository.findById(userId);

        if (applicationOpt.isEmpty()) {
            throw new Exception("Application not found");
        }

        if (userOpt.isEmpty()) {
            throw new Exception("User not found");
        }

        Review review = new Review();
        review.setContent(content);
        review.setRating(rating);
        review.setApplication(applicationOpt.get());
        review.setUser(userOpt.get());

        return reviewRepository.save(review);
    }

    public List<Review> getReviewsByApplicationId(Long applicationId) {
        return reviewRepository.findByApplicationId(applicationId);
    }

    public List<Review> getReviewsByUserId(Long userId) {
        return reviewRepository.findByUserId(userId);
    }

    public void deleteReview(Long reviewId, Long userId) throws Exception {
        Optional<Review> reviewOpt = reviewRepository.findById(reviewId);

        if (reviewOpt.isEmpty()) {
            throw new Exception("Review not found");
        }

        Review review = reviewOpt.get();

        if (!review.getUser().getId().equals(userId)) {
            throw new Exception("User not authorized to delete this review");
        }

        reviewRepository.delete(review);
    }

	public Review addReview1(Long applicationId, Long userId, String content, int rating) {
		// TODO Auto-generated method stub
		return null;
	}
}
