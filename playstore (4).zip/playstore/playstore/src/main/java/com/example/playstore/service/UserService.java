package com.example.playstore.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.playstore.entity.User;
import com.example.playstore.repository.UserRepository;

@Service
public class UserService {

 @Autowired
 private UserRepository userRepository;

 public User registerUser(User user) {
     return null;//userRepository.save(user);
    
 }

 public User findByUsername(String username) {
     return userRepository.findByUsername(username);
 }

public Optional<User> findById(Long userId) {
	// TODO Auto-generated method stub
	return null;// userRepository.findById(userId);
}

 // Additional methods for login, logout, etc.
}
