package com.example.playstore.controller;

//src/main/java/com/example/playstore/controller/NotificationController.java



import com.example.playstore.entity.Notification;
import com.example.playstore.entity.User;
import com.example.playstore.service.NotificationService;
import com.example.playstore.service.UserService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

 @Autowired
 private NotificationService notificationService;

 @Autowired
 private UserService userService;

 // Endpoint to send a notification to a user
 @PostMapping("/send")
 public ResponseEntity<Notification> sendNotification(@RequestParam String message, @RequestParam Long userId) {
     Optional<User> user = userService.findById(userId);  // Assuming userService provides a method to fetch a user by ID
     if (user != null) {
         Notification notification = notificationService.sendNotification(message, user);
         return new ResponseEntity<>(notification, HttpStatus.OK);
     }
     return new ResponseEntity<>(HttpStatus.NOT_FOUND);
 }
}

