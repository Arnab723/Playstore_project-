package com.example.playstoreowner.controller;

import com.example.playstoreowner.entity.Application;
import com.example.playstoreowner.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/owner/applications")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    @PostMapping
    public ResponseEntity<Application> createApplication(@RequestBody Application application) {
        return ResponseEntity.ok(applicationService.createApplication(application));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Application> updateApplication(@PathVariable Long id, @RequestBody Application application) {
        application.setId(id);
        return ResponseEntity.ok(applicationService.updateApplication(application));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteApplication(@PathVariable Long id) {
        applicationService.deleteApplication(id);
        return ResponseEntity.ok("Application Deleted Successfully");
    }

    @GetMapping
    public ResponseEntity<List<Application>> getApplicationsByOwnerId(@RequestParam Long ownerId) {
        return ResponseEntity.ok(applicationService.getApplicationsByOwnerId(ownerId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Application> getApplicationById(@PathVariable Long id) {
        return ResponseEntity.ok(applicationService.getApplicationById(id));
    }

    @PutMapping("/{id}/visibility")
    public ResponseEntity<Application> setApplicationVisibility(@PathVariable Long id, @RequestParam boolean isVisible) {
        Application application = applicationService.getApplicationById(id);
        if (application != null) {
            application.setVisible(isVisible);
            applicationService.updateApplication(application);
            return ResponseEntity.ok(application);
        }
        return ResponseEntity.notFound().build();
    }
}