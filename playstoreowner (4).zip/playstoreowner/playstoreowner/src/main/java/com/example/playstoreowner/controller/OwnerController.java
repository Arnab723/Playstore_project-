package com.example.playstoreowner.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.playstoreowner.entity.Owner;
import com.example.playstoreowner.service.OwnerService;

@RestController
@RequestMapping("/api/owners")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;

    // Register a new owner
    @PostMapping("/register")
    public ResponseEntity<Owner> registerOwner(@RequestBody Owner owner) {
        Owner registeredOwner = ownerService.registerOwner(owner);
        return new ResponseEntity<>(registeredOwner, HttpStatus.CREATED);
    }

    // Login owner (for simplicity, this example doesn't include JWT handling)
    @PostMapping("/login")
    public ResponseEntity<String> loginOwner(@RequestBody Owner owner) {
        Owner existingOwner = ownerService.findByUsername(owner.getUsername());
        if (existingOwner != null && existingOwner.getPassword().equals(owner.getPassword())) {
            // In a real application, you would return a JWT token here
            return new ResponseEntity<>("Login successful", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
    }

    // Get owner details by username
    @GetMapping("/{username}")
    public ResponseEntity<Owner> getOwnerByUsername(@PathVariable String username) {
        Owner owner = ownerService.findByUsername(username);
        if (owner != null) {
            return new ResponseEntity<>(owner, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Update an existing owner
    @PutMapping("/update/{id}")
    public ResponseEntity<Owner> updateOwner(@PathVariable Long id, @RequestBody Owner ownerDetails) {
        Owner updatedOwner = ownerService.updateOwner(id, ownerDetails);
        if (updatedOwner != null) {
            return new ResponseEntity<>(updatedOwner, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete an owner
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteOwner(@PathVariable Long id) {
        boolean isDeleted = ownerService.deleteOwner(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
