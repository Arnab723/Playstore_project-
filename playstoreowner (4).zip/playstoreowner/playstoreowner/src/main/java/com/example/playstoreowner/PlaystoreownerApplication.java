package com.example.playstoreowner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class PlaystoreownerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaystoreownerApplication.class, args);
	}

}
