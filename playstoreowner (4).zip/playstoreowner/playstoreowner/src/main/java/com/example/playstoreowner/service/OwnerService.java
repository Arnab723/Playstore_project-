package com.example.playstoreowner.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.playstoreowner.entity.Owner;
import com.example.playstoreowner.repository.OwnerRepository;

@Service
public class OwnerService {

    @Autowired
    private OwnerRepository ownerRepository;

    public Owner registerOwner(Owner owner) {
        return ownerRepository.save(owner);
    }

    public Owner findByUsername(String username) {
        return ownerRepository.findByUsername(username);
    }

    public Owner updateOwner(Long id, Owner ownerDetails) {
        return ownerRepository.findById(id).map(owner -> {
            owner.setUsername(ownerDetails.getUsername());
            owner.setPassword(ownerDetails.getPassword());
            owner.setEmail(ownerDetails.getEmail());
            return ownerRepository.save(owner);
        }).orElse(null);
    }

    public boolean deleteOwner(Long id) {
        return ownerRepository.findById(id).map(owner -> {
            ownerRepository.delete(owner);
            return true;
        }).orElse(false);
    }

	public Owner getOwnerById(Long ownerId) {
		// TODO Auto-generated method stub
		return null;
	}
}
