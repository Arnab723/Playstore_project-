package com.example.playstoreowner.service;

import com.example.playstoreowner.entity.Owner;
import com.example.playstoreowner.repository.OwnerRepository;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private OwnerRepository ownerRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Owner owner = ownerRepository.findByUsername(username);

        return new User(owner.getUsername(), owner.getPassword(),
                new ArrayList<>()); // Assuming no roles are required for this example
    }

	public UserDetails loadUserByUsername(Object username) {
		// TODO Auto-generated method stub
		return null;
	}
}
