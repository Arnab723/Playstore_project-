package com.example.playstoreowner.entity;

import java.util.Date;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "applications")
public class Application {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @Column(nullable = false)
 private String name;

 @Column(nullable = false, columnDefinition = "TEXT")
 private String description;

 @Column(nullable = false)
 private Date releaseDate;

 @Column(nullable = false)
 private String version;

 @Column(nullable = false)
 private float ratings;

 @Column(nullable = false)
 private String genre;

 @ManyToOne
 @JoinColumn(name = "owner_id", nullable = false)
 private Owner owner;
 
 private int download_count;

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public Date getReleaseDate() {
	return releaseDate;
}

public void setReleaseDate(Date releaseDate) {
	this.releaseDate = releaseDate;
}

public String getVersion() {
	return version;
}

public void setVersion(String version) {
	this.version = version;
}

public float getRatings() {
	return ratings;
}

public void setRatings(float ratings) {
	this.ratings = ratings;
}

public String getGenre() {
	return genre;
}

public void setGenre(String genre) {
	this.genre = genre;
}

public Owner getOwner() {
	return owner;
}

public void setOwner(Owner owner) {
	this.owner = owner;
}

public int getDownload_count() {
	return download_count;
}

public void setDownload_count(int download_count) {
	this.download_count = download_count;
}

public Object isVisible() {
	// TODO Auto-generated method stub
	return null;
}

public void setVisible(Object visible) {
	// TODO Auto-generated method stub
	
}
 
 

 // Getters and Setters
 
}


